# IT Quiz Final
Install Python 3.10+, then:
pip install -r requirements.txt
python app.py

Presenter: http://SERVER-IP:5000/
Control: http://SERVER-IP:5000/control

Edit data/quiz.xlsx to replace the sample questions. Results are saved to data/results.xlsx.
Put these files in static/sounds/: correct.mp3, wrong.mp3, timeout.mp3, tick.mp3.
For LAN access, allow Python/port 5000 through Windows Firewall.
