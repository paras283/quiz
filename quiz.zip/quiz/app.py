from flask import Flask, render_template, jsonify, request
from openpyxl import load_workbook
from pathlib import Path
from threading import Lock
from datetime import datetime
import time

app=Flask(__name__)
BASE=Path(__file__).resolve().parent
QUIZ=BASE/"data/quiz.xlsx"; RESULTS=BASE/"data/results.xlsx"
HOUSES=["Sahyadri","Nilgiri","Vindhyachal","Himalaya"]
ROUNDS=4; QPH=4; lock=Lock()

def load_data():
    wb=load_workbook(QUIZ,data_only=True)
    sh=wb["Questions"]; heads=[c.value for c in sh[1]]; data=[]
    for row in sh.iter_rows(min_row=2,values_only=True):
        if not row[0]: continue
        d=dict(zip(heads,row))
        data.append({"id":d["ID"],"round":int(d["Round"]),"qno":int(d["QNo"]),"house":str(d["House"]),
        "question":str(d["Question"]),"options":{k:str(d[k]) for k in "ABCD"},"correct":str(d["Correct"]).upper(),
        "positive":int(d["Positive"]),"negative":int(d["Negative"]),"time":int(d["Time"])})
    return data

questions=load_data()
state={"status":"idle","round":1,"house_index":0,"house":HOUSES[0],"q_index":0,
"question_number":1,"question":None,"timer_duration":30,"timer_started":None,
"paused":None,"last_result":None,"scores":{h:0 for h in HOUSES},"revision":0,
"rapid":False,"rapid_house":0,"rapid_q":0,"rapid_started":None,"rapid_duration":60}

def getq():
    if state["rapid"]: return None
    for q in questions:
        if q["round"]==state["round"] and q["house"]==state["house"] and q["qno"]==state["question_number"]: return q
    return None

def setq():
    state["question"]=getq()
    state["last_result"]=None
    state["timer_duration"]=state["question"]["time"] if state["question"] else 30
    state["timer_started"]=None; state["paused"]=None; state["revision"]+=1

def public():
    s=dict(state); s["scores"]=dict(state["scores"])
    if s["question"]: s["question"]={k:v for k,v in s["question"].items() if k!="correct"}
    return s

def save(round_no,house,q,selected,result,marks):
    wb=load_workbook(RESULTS); sh=wb["Question Results"]
    sh.append([datetime.now().strftime("%Y-%m-%d %H:%M:%S"),round_no,house,q.get("qno","Rapid"),q["question"],selected or "",q["correct"],result,marks])
    hs=wb["House Scores"]
    vals=sorted(state["scores"].items(),key=lambda x:x[1],reverse=True)
    for r in range(2,hs.max_row+1):
        h=hs.cell(r,1).value
        if h in state["scores"]: hs.cell(r,7).value=state["scores"][h]
        if h in dict(vals): hs.cell(r,8).value=next(i for i,(hh,_) in enumerate(vals,1) if hh==h)
    fr=wb["Final Results"]
    for r in range(fr.max_row,1,-1): fr.delete_rows(r)
    for rank,(h,score) in enumerate(vals,1): fr.append([rank,h,score])
    wb.save(RESULTS)

def answer(selected,timeout=False):
    q=state["question"]
    if not q:return
    if timeout: correct=False; marks=0; result="TIME UP"
    else:
        correct=str(selected).upper()==q["correct"]; marks=q["positive"] if correct else q["negative"]; result="CORRECT" if correct else "WRONG"
    state["scores"][state["house"]]+=marks
    state["last_result"]={"id":time.time_ns(),"selected":selected,"correct":correct,"correct_answer":q["correct"],"delta":marks,"reason":"timeout" if timeout else "answer"}
    save(state["round"],state["house"],q,selected,result,marks)
    state["status"]="answered"; state["timer_started"]=None; state["revision"]+=1

@app.route("/")
def presenter(): return render_template("presenter.html")
@app.route("/control")
def control(): return render_template("control.html")
@app.get("/api/state")
def api_state(): return jsonify(public())

@app.post("/api/start")
def start():
    with lock:
        if state["status"]=="rapid_ready":
            state["rapid"]=True; state["status"]="running"; state["rapid_house"]=0; state["house"]=HOUSES[0]; state["rapid_q"]=0; state["rapid_started"]=time.time(); state["question"]=None; state["revision"]+=1
        else:
            state["status"]="running"; state["timer_started"]=time.time(); state["revision"]+=1
        return jsonify(public())

@app.post("/api/pause")
def pause():
    with lock:
        if state["status"]=="running" and not state["rapid"]:
            state["paused"]=max(0,state["timer_duration"]-(time.time()-state["timer_started"])); state["timer_started"]=None; state["status"]="paused"; state["revision"]+=1
        return jsonify(public())

@app.post("/api/resume")
def resume():
    with lock:
        if state["status"]=="paused":
            state["timer_duration"]=state["paused"] or state["timer_duration"]; state["timer_started"]=time.time(); state["status"]="running"; state["revision"]+=1
        return jsonify(public())

@app.post("/api/answer")
def api_answer():
    with lock:
        if state["status"]=="running" and not state["rapid"]: answer((request.get_json() or {}).get("answer"))
        return jsonify(public())

@app.post("/api/no-answer")
def noanswer():
    with lock:
        if state["status"]=="running" and not state["rapid"]: answer(None,True)
        return jsonify(public())

@app.post("/api/next")
def nextq():
    with lock:
        if state["rapid"]:
            state["rapid_q"]+=1; state["revision"]+=1
        else:
            state["q_index"]+=1
            if state["q_index"]<QPH:
                state["question_number"]=state["q_index"]+1; setq()
            else:
                state["house_index"]+=1
                if state["house_index"]<len(HOUSES):
                    state["house"]=HOUSES[state["house_index"]]; state["q_index"]=0; state["question_number"]=1; setq()
                else:
                    state["house_index"]=0; state["house"]=HOUSES[0]; state["q_index"]=0; state["question_number"]=1; state["round"]+=1
                    if state["round"]<=ROUNDS: setq()
                    else: state["status"]="rapid_ready"; state["rapid"]=True; state["question"]=None; state["revision"]+=1
        return jsonify(public())

@app.post("/api/previous")
def prevq():
    with lock:
        if state["rapid"]: state["rapid_q"]=max(0,state["rapid_q"]-1); state["revision"]+=1
        elif state["q_index"]>0: state["q_index"]-=1; state["question_number"]=state["q_index"]+1; setq()
        return jsonify(public())

@app.post("/api/manual-score")
def manual():
    with lock:
        d=request.get_json() or {}; h=d.get("house"); delta=int(d.get("delta",0))
        if h in state["scores"]: state["scores"][h]+=delta; state["revision"]+=1
        return jsonify(public())

@app.post("/api/reset")
def reset():
    with lock:
        state.update({"status":"idle","round":1,"house_index":0,"house":HOUSES[0],"q_index":0,"question_number":1,"rapid":False,"rapid_house":0,"rapid_q":0,"rapid_started":None,"last_result":None,"scores":{h:0 for h in HOUSES}})
        setq(); return jsonify(public())

@app.post("/api/reload-excel")
def reload():
    global questions
    with lock: questions=load_data(); setq(); return jsonify(public())

@app.get("/api/tick")
def tick():
    with lock:
        if state["status"]=="running" and not state["rapid"] and state["timer_started"]:
            if time.time()-state["timer_started"]>=state["timer_duration"]: answer(None,True)
        if state["rapid"] and state["status"]=="running" and state["rapid_started"] and time.time()-state["rapid_started"]>=state["rapid_duration"]:
            state["status"]="rapid_finished"; state["rapid_started"]=None; state["revision"]+=1
        return jsonify(public())

setq()
if __name__=="__main__": app.run(host="0.0.0.0",port=5000,debug=True,threaded=True)
