Add: correct.mp3, wrong.mp3, timeout.mp3, tick.mp3
