const $=s=>document.querySelector(s), $$=s=>document.querySelectorAll(s);
let current=null;
let requestVersion=0;
let pollVersion=0;
let latestEvent=-1;

async function post(url,data={}){
  const version=++requestVersion;
  try{
    const r=await fetch(url,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(data)});
    const j=await r.json();
    if(!r.ok) alert(j.error||'Request failed');
    // If the action returned authoritative state, render it immediately.
    // This prevents an older polling request from restoring the previous
    // START/PAUSE/RESUME state after NEXT QUESTION.
    // Server event numbers are authoritative. Never allow a stale poll/action
    // response to replace a newer quiz state.
    if(j.state && j.state.last_event >= latestEvent){
      latestEvent=j.state.last_event;
      render(j.state);
    }
    return j;
  }catch(e){ alert('Unable to communicate with the quiz server.'); return {ok:false}; }
}

function setButtonState(s){
  const start=$('#start'), pause=$('#pause'), resume=$('#resume'), next=$('#next'), prev=$('#prev');
  const ready = !s.quiz_finished && !s.evaluated && s.status === 'ready';
  const running = !s.quiz_finished && !s.evaluated && s.status === 'running';
  const paused = !s.quiz_finished && !s.evaluated && s.status === 'paused';
  const evaluated = !s.quiz_finished && s.evaluated && s.status === 'evaluated';

  start.disabled = !ready;
  pause.disabled = !running;
  resume.disabled = !paused;
  next.disabled = !evaluated;
  prev.disabled = !!s.rapid || !!s.quiz_finished;

  start.dataset.state = ready ? 'ready' : 'disabled';
  pause.dataset.state = running ? 'active' : 'disabled';
  resume.dataset.state = paused ? 'active' : 'disabled';
  next.dataset.state = evaluated ? 'active' : 'disabled';
  start.textContent = s.rapid ? 'START RAPID FIRE' : 'START';
  pause.textContent = running ? 'PAUSE TIMER' : 'PAUSE';
  resume.textContent = paused ? 'RESUME TIMER' : 'RESUME';
}

function render(s){
  current=s;
  $('#round').textContent=s.quiz_finished?'FINAL RESULT':s.rapid?'RAPID FIRE — '+s.rapid_house:'Round '+s.round;
  $('#qno').textContent=s.quiz_finished?'QUIZ COMPLETE':s.rapid?'Question '+s.rapid_question+' / 10':'Question '+s.question_number+' / 8';
  $('#house').textContent=s.house||s.rapid_house||'SELECT HOUSE';
  $('#status').textContent=s.status.replace('_',' ').toUpperCase();
  $('#time').textContent=Math.ceil(s.remaining||0);
  $('#question').textContent=s.quiz_finished?'Rapid Fire complete — final results are ready.':(s.question?.Question||'Select an answering house');
  $('#options').innerHTML=s.question&&!s.quiz_finished?['A','B','C','D'].filter(k=>s.question[k]).map(k=>`<div class="option"><b>${k}.</b> ${s.question[k]}</div>`).join(''):'';
  $('#rapidInfo').textContent=s.rapid?`CURRENT HOUSE: ${s.rapid_house} • QUESTION ${s.rapid_question} / 10`:(s.quiz_finished?'Completed':'Not started');
  $('#errors').innerHTML=(s.validation_errors||[]).map(e=>`<div>${e}</div>`).join('');

  const pg=$('.houseGrid');
  pg.innerHTML='';
  if([3,4].includes(s.round)&&!s.rapid&&!s.quiz_finished){
    s.houses.forEach(h=>{
      const b=document.createElement('button');
      b.className='houseBtn'; b.textContent=h.name.toUpperCase(); b.style.background=h.color;
      b.onclick=()=>post('/api/select-house',{house:h.name}).then(j=>{if(!j.state) poll();});
      pg.appendChild(b);
    });
  }
  $('#passing').style.display=([3,4].includes(s.round)&&!s.rapid&&!s.quiz_finished)?'block':'none';
  setButtonState(s);
}

async function poll(){
  const myVersion=++pollVersion;
  try{
    const s=await fetch('/api/state',{cache:'no-store'}).then(r=>r.json());
    // Never let an older polling response overwrite the state produced by a
    // newer button action.
    // A poll response may have been generated before a button action.
    // Compare the server's monotonic event number instead of request timing.
    if(s.last_event >= latestEvent){
      latestEvent=s.last_event;
      render(s);
    }
  }catch(e){}
}

$('#start').onclick=async()=>{const j=await post('/api/start');if(!j.state) poll();};
$('#pause').onclick=async()=>{const j=await post('/api/pause');if(!j.state) poll();};
$('#resume').onclick=async()=>{const j=await post('/api/resume');if(!j.state) poll();};
$('#next').onclick=async()=>{const j=await post('/api/next');if(!j.state) poll();};
$('#prev').onclick=async()=>{const j=await post('/api/previous');if(!j.state) poll();};
$('#noanswer').onclick=async()=>{const j=await post('/api/no-answer');if(!j.state) poll();};

$$('[data-result]').forEach(b=>b.onclick=async()=>{
  const j=await post(current?.rapid?'/api/rapid-result':'/api/answer',{result:b.dataset.result});
  if(!j.state) poll();
});

$('#rapidNext').onclick=async()=>{const j=await post('/api/next');if(!j.state) poll();};
$('#rapidPass').onclick=async()=>{const j=await post('/api/rapid-result',{result:'wrong'});if(!j.state) poll();};
$('#reload').onclick=async()=>{const j=await post('/api/reload-excel');alert(j.ok?'Questions reloaded':'Reload failed');poll();};
$('#reset').onclick=async()=>{if(confirm('Are you sure you want to reset the entire quiz?')){const j=await post('/api/reset');if(!j.state) poll();}};

function manual(){
  const g=$('#manualGrid');
  ['Sahyadri','Vindhyachal','Nilgiri','Himalaya'].forEach(h=>{
    const d=document.createElement('div'); d.className='manualCard';
    d.innerHTML=`<strong>${h}</strong><div class="scoreBtns"><button data-h="${h}" data-d="5">+5</button><button data-h="${h}" data-d="10">+10</button><button data-h="${h}" data-d="-5">-5</button><button data-h="${h}" data-d="-10">-10</button></div>`;
    g.appendChild(d);
  });
  g.onclick=e=>{if(e.target.dataset.h) post('/api/manual-score',{house:e.target.dataset.h,delta:Number(e.target.dataset.d)}).then(j=>{if(!j.state) poll();});};
}
manual();
setInterval(poll,500);
poll();
