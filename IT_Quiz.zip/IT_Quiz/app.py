from flask import Flask, jsonify, render_template, request
from openpyxl import load_workbook, Workbook
from pathlib import Path
from datetime import datetime
import threading, time, copy

BASE = Path(__file__).resolve().parent
DATA = BASE / 'data'
QUIZ_FILE = DATA / 'quiz.xlsx'
RESULT_FILE = DATA / 'results.xlsx'

HOUSES = [
    {'name': 'Sahyadri', 'color': '#ef4444'},
    {'name': 'Vindhyachal', 'color': '#22c55e'},
    {'name': 'Nilgiri', 'color': '#3b82f6'},
    {'name': 'Himalaya', 'color': '#facc15'},
]
HOUSE_NAMES = [h['name'] for h in HOUSES]
NORMAL_SEQUENCE = ['Sahyadri','Vindhyachal','Nilgiri','Himalaya','Himalaya','Nilgiri','Vindhyachal','Sahyadri']
ROUNDS = [1,2,3,4]

app = Flask(__name__)
lock = threading.RLock()
questions = {1: [], 2: [], 3: [], 4: []}
rapid = {h: [] for h in HOUSE_NAMES}
validation_errors = []

state = {
    'round': 1, 'question_number': 1, 'house': 'Sahyadri', 'status': 'ready',
    'scores': {h: 0 for h in HOUSE_NAMES}, 'answer_result': None,
    'selected_answer': None, 'evaluated': False, 'started_at': None,
    'paused_at': None, 'remaining': 0, 'rapid': False, 'rapid_house': None,
    'rapid_question': 1, 'quiz_finished': False, 'last_event': 0,
}


def required_columns(sheet, cols):
    headers = [str(c.value).strip() if c.value is not None else '' for c in sheet[1]]
    missing = [c for c in cols if c not in headers]
    return headers, missing


def read_questions():
    global validation_errors, questions, rapid
    errors = []
    new_q = {1: [], 2: [], 3: [], 4: []}
    new_r = {h: [] for h in HOUSE_NAMES}
    if not QUIZ_FILE.exists():
        errors.append(f'Missing Excel file: {QUIZ_FILE}')
    else:
        try:
            wb = load_workbook(QUIZ_FILE, data_only=True)
            for s in ('Questions','RapidFire'):
                if s not in wb.sheetnames:
                    errors.append(f'Missing required sheet: {s}')
            if not errors:
                ws = wb['Questions']
                cols = ['ID','Round','QNo','House','Type','Question','A','B','C','D','Correct','Positive','Negative','Time']
                headers, missing = required_columns(ws, cols)
                if missing:
                    errors.append('Questions sheet missing columns: ' + ', '.join(missing))
                else:
                    idx = {h:i for i,h in enumerate(headers)}
                    for row in ws.iter_rows(min_row=2, values_only=True):
                        if not any(v is not None for v in row): continue
                        try:
                            r = int(row[idx['Round']]); qno = int(row[idx['QNo']])
                            correct = str(row[idx['Correct']]).strip().upper()
                            pos = float(row[idx['Positive']]); neg = float(row[idx['Negative']]); tm = float(row[idx['Time']])
                            if r not in ROUNDS: raise ValueError('Round must be 1-4')
                            if correct not in 'ABCD': raise ValueError('Correct must be A/B/C/D')
                            if tm <= 0: raise ValueError('Time must be greater than zero')
                            item = {k: row[idx[k]] for k in ['ID','Round','QNo','House','Type','Question','A','B','C','D']}
                            item.update({'Correct': correct, 'Positive': pos, 'Negative': neg, 'Time': tm})
                            new_q[r].append(item)
                        except Exception as e:
                            errors.append(f'Questions row {ws.max_row}: invalid data ({e})')
                    for r in ROUNDS:
                        new_q[r].sort(key=lambda x: x['QNo'])
                        if len(new_q[r]) != 8: errors.append(f'Round {r} contains {len(new_q[r])} questions. Expected 8.')
                    for r in (1,2):
                        houses = [x.get('House') for x in new_q[r]]
                        if houses != NORMAL_SEQUENCE:
                            errors.append(f'Round {r} house sequence does not match the configured sequence.')
                ws = wb['RapidFire']
                cols = ['ID','House','QNo','Question','Correct','Positive','Negative','Time']
                headers, missing = required_columns(ws, cols)
                if missing:
                    errors.append('RapidFire sheet missing columns: ' + ', '.join(missing))
                else:
                    idx = {h:i for i,h in enumerate(headers)}
                    for row in ws.iter_rows(min_row=2, values_only=True):
                        if not any(v is not None for v in row): continue
                        try:
                            h = str(row[idx['House']]).strip(); qno = int(row[idx['QNo']]); correct = str(row[idx['Correct']]).strip().upper()
                            pos=float(row[idx['Positive']]); neg=float(row[idx['Negative']]); tm=float(row[idx['Time']])
                            if h not in HOUSE_NAMES: raise ValueError('Invalid house')
                            if correct not in 'ABCD': raise ValueError('Correct must be A/B/C/D')
                            if tm <= 0: raise ValueError('Time must be greater than zero')
                            item={k:row[idx[k]] for k in ['ID','House','QNo','Question']}
                            item.update({'Correct':correct,'Positive':pos,'Negative':neg,'Time':tm})
                            new_r[h].append(item)
                        except Exception as e: errors.append(f'RapidFire row invalid ({e})')
                    for h in HOUSE_NAMES:
                        new_r[h].sort(key=lambda x:x['QNo'])
                        if len(new_r[h]) != 10: errors.append(f'Rapid Fire for {h} contains {len(new_r[h])} questions. Expected 10.')
        except Exception as e:
            errors.append(f'Unable to read Excel: {e}')
    with lock:
        validation_errors = errors
        if not errors:
            questions, rapid = new_q, new_r
    return errors


def ensure_results():
    DATA.mkdir(exist_ok=True)
    if not RESULT_FILE.exists():
        wb=Workbook(); ws=wb.active; ws.title='Results'
        ws.append(['Timestamp','Round','Question Number','House','Question','Selected Answer','Correct Answer','Result','Marks Awarded'])
        sc=wb.create_sheet('House Scores'); sc.append(['House','Score'])
        for h in HOUSE_NAMES: sc.append([h,0])
        fr=wb.create_sheet('Final Results'); fr.append(['Rank','House','Score'])
        wb.save(RESULT_FILE)


def log_result(round_no, qno, house, q, selected, result, marks):
    try:
        ensure_results(); wb=load_workbook(RESULT_FILE)
        ws=wb['Results']; ws.append([datetime.now().strftime('%Y-%m-%d %H:%M:%S'),round_no,qno,house,q.get('Question',''),selected or '',q.get('Correct',''),result,marks])
        sc=wb['House Scores']
        for row in sc.iter_rows(min_row=2):
            if row[0].value == house: row[1].value = state['scores'][house]
        fr=wb['Final Results']; fr.delete_rows(2, max(0,fr.max_row-1))
        ranked=sorted(state['scores'].items(), key=lambda x:(-x[1], HOUSE_NAMES.index(x[0])))
        for i,(h,s) in enumerate(ranked,1): fr.append([i,h,s])
        wb.save(RESULT_FILE)
    except Exception:
        pass


def current_question():
    if state['rapid']:
        arr=rapid.get(state['rapid_house'],[]); i=state['rapid_question']-1
        return arr[i] if 0 <= i < len(arr) else None
    arr=questions.get(state['round'],[]); i=state['question_number']-1
    return arr[i] if 0 <= i < len(arr) else None


def public_state():
    with lock:
        s=copy.deepcopy(state)
        q=current_question()
        s['question'] = None if not q else {k:q.get(k) for k in ['ID','Round','QNo','House','Type','Question','A','B','C','D','Correct','Positive','Negative','Time'] if k != 'Correct'}
        s['validation_errors']=list(validation_errors)
        s['houses']=HOUSES
        s['server_time']=time.time()
        s['final_ranking']=sorted([{'house':h,'score':v} for h,v in s['scores'].items()], key=lambda x:(-x['score'], HOUSE_NAMES.index(x['house'])))
        return s


def reset_state():
    state.update({'round':1,'question_number':1,'house':NORMAL_SEQUENCE[0],'status':'ready','scores':{h:0 for h in HOUSE_NAMES},'answer_result':None,'selected_answer':None,'evaluated':False,'started_at':None,'paused_at':None,'remaining':0,'rapid':False,'rapid_house':None,'rapid_question':1,'quiz_finished':False})
    state['last_event'] += 1


def start_timer():
    q=current_question()
    if not q: return
    state['started_at']=time.time(); state['remaining']=float(q['Time']); state['status']='running'; state['last_event'] += 1


def remaining_time():
    if state['status']=='running' and state['started_at'] is not None:
        return max(0, state['remaining'] - (time.time()-state['started_at']))
    return max(0, state['remaining'])


def auto_timeout_if_needed():
    with lock:
        if state['status']=='running' and remaining_time() <= 0:
            q=current_question(); house=state['house']
            if q and not state['evaluated']:
                marks=0
                state['evaluated']=True; state['answer_result']='timeout'; state['selected_answer']=None; state['scores'][house]+=marks
                log_result('Rapid Fire' if state['rapid'] else state['round'], state['rapid_question'] if state['rapid'] else state['question_number'], house, q, None, 'TIME UP', marks)
            state['status']='evaluated'; state['remaining']=0; state['started_at']=None; state['last_event'] += 1


@app.route('/')
def presenter(): return render_template('presenter.html')
@app.route('/control')
def control(): return render_template('control.html')

@app.get('/api/state')
def api_state():
    auto_timeout_if_needed(); s=public_state(); s['remaining']=remaining_time(); return jsonify(s)
@app.get('/api/tick')
def api_tick():
    auto_timeout_if_needed(); return jsonify({'remaining':remaining_time(),'status':state['status'],'server_time':time.time(),'event':state['last_event']})

@app.post('/api/start')
def api_start():
    with lock:
        if validation_errors: return jsonify(ok=False,error='Excel validation failed',details=validation_errors),400
        if state['quiz_finished']: return jsonify(ok=False,error='Quiz is already finished'),400
        if state['status']=='select_house' and state['house'] not in HOUSE_NAMES: return jsonify(ok=False,error='Select an answering house first'),400
        if state['evaluated']: return jsonify(ok=False,error='Question already evaluated. Click Next.'),400
        start_timer()
    return jsonify(ok=True,state=public_state())

@app.post('/api/pause')
def api_pause():
    with lock:
        if state['status']!='running': return jsonify(ok=False,error='Timer is not running'),400
        state['remaining']=remaining_time(); state['started_at']=None; state['status']='paused'; state['last_event']+=1
    return jsonify(ok=True,state=public_state())

@app.post('/api/resume')
def api_resume():
    with lock:
        if state['status']!='paused': return jsonify(ok=False,error='Timer is not paused'),400
        state['started_at']=time.time(); state['status']='running'; state['last_event']+=1
    return jsonify(ok=True,state=public_state())

@app.post('/api/select-house')
def select_house():
    h=(request.json or {}).get('house')
    with lock:
        if state['round'] not in (3,4) or state['rapid']: return jsonify(ok=False,error='House selection is only available in passing rounds'),400
        if h not in HOUSE_NAMES: return jsonify(ok=False,error='Invalid house'),400
        if state['status'] not in ('select_house','ready','paused'): return jsonify(ok=False,error='Cannot change house after evaluation has started'),400
        state['house']=h; state['status']='ready'; state['evaluated']=False; state['answer_result']=None; state['selected_answer']=None; state['last_event']+=1
    return jsonify(ok=True,state=public_state())

@app.post('/api/answer')
def answer():
    data=request.json or {}; result=str(data.get('result','')).lower(); selected=data.get('answer')
    with lock:
        if result not in ('correct','wrong'): return jsonify(ok=False,error='Result must be correct or wrong'),400
        if state['evaluated']: return jsonify(ok=False,error='Question already evaluated'),400
        if state['status'] not in ('running','paused','ready'): return jsonify(ok=False,error='Question is not active'),400
        q=current_question(); house=state['house']
        if not q: return jsonify(ok=False,error='No question loaded'),400
        marks=float(q['Positive']) if result=='correct' else float(q['Negative'])
        state['scores'][house]+=marks; state['evaluated']=True; state['answer_result']=result; state['selected_answer']=selected
        state['remaining']=remaining_time(); state['started_at']=None; state['status']='evaluated'; state['last_event']+=1
        log_result(state['round'] if not state['rapid'] else 'Rapid Fire', state['question_number'] if not state['rapid'] else state['rapid_question'], house,q,selected,result,marks)
    return jsonify(ok=True,marks=marks,state=public_state())

@app.post('/api/no-answer')
def no_answer():
    with lock:
        if state['evaluated']: return jsonify(ok=False,error='Question already evaluated'),400
        q=current_question(); house=state['house']
        if not q: return jsonify(ok=False,error='No question loaded'),400
        state['evaluated']=True; state['answer_result']='timeout'; state['selected_answer']=None; state['remaining']=0; state['started_at']=None; state['status']='evaluated'; state['last_event']+=1
        log_result(state['round'] if not state['rapid'] else 'Rapid Fire', state['question_number'] if not state['rapid'] else state['rapid_question'], house,q,None,'TIME UP',0)
    return jsonify(ok=True,state=public_state())

@app.post('/api/rapid-result')
def rapid_result(): return answer()

@app.post('/api/next')
def next_q():
    with lock:
        if validation_errors: return jsonify(ok=False,error='Excel validation failed',details=validation_errors),400
        if not state['evaluated'] and state['status'] not in ('ready','select_house'): return jsonify(ok=False,error='Evaluate the current question before moving next.'),400
        if state['rapid']:
            if state['rapid_question'] < 10:
                state['rapid_question']+=1
            else:
                i=HOUSE_NAMES.index(state['rapid_house'])
                if i < 3:
                    # Move BOTH rapid-house and active scoring house to the
                    # next house.  Previously rapid_house changed but
                    # state['house'] remained Sahyadri, so all Rapid Fire
                    # answers continued adding points to Sahyadri.
                    state['rapid_house']=HOUSE_NAMES[i+1]
                    state['house']=HOUSE_NAMES[i+1]
                    state['rapid_question']=1
                else:
                    state['quiz_finished']=True; state['status']='finished'; state['last_event']+=1; return jsonify(ok=True,finished=True,state=public_state())
            state['status']='ready'; state['evaluated']=False; state['answer_result']=None; state['selected_answer']=None; state['remaining']=0; state['started_at']=None; state['last_event']+=1
            return jsonify(ok=True,state=public_state())
        if state['question_number'] < 8:
            state['question_number'] += 1
            if state['round'] in (1,2):
                # Every normal-round question must enter a fresh READY state.
                # Previously the status remained EVALUATED after Q1, which
                # permanently disabled START on Q2 and subsequent questions.
                state['house'] = NORMAL_SEQUENCE[state['question_number'] - 1]
                state['status'] = 'ready'
            else:
                state['status'] = 'select_house'
                state['house'] = None
        else:
            if state['round'] < 4:
                state['round']+=1; state['question_number']=1; state['house']=NORMAL_SEQUENCE[0] if state['round'] in (1,2) else None; state['status']='ready' if state['round'] in (1,2) else 'select_house'
            else:
                state['rapid']=True; state['rapid_house']=HOUSE_NAMES[0]; state['rapid_question']=1; state['question_number']=1; state['house']=HOUSE_NAMES[0]; state['status']='ready'
        state['evaluated']=False; state['answer_result']=None; state['selected_answer']=None; state['remaining']=0; state['started_at']=None; state['last_event']+=1
    return jsonify(ok=True,state=public_state())

@app.post('/api/previous')
def previous_q():
    with lock:
        if state['rapid']: return jsonify(ok=False,error='Previous is disabled in Rapid Fire'),400
        if state['question_number']>1: state['question_number']-=1
        elif state['round']>1: state['round']-=1; state['question_number']=8
        else: return jsonify(ok=False,error='Already at first question'),400
        if state['round'] in (1,2): state['house']=NORMAL_SEQUENCE[state['question_number']-1]; state['status']='ready'
        else: state['house']=None; state['status']='select_house'
        state['evaluated']=False; state['answer_result']=None; state['selected_answer']=None; state['remaining']=0; state['started_at']=None; state['last_event']+=1
    return jsonify(ok=True,state=public_state())

@app.post('/api/manual-score')
def manual_score():
    data=request.json or {}; h=data.get('house'); delta=float(data.get('delta',0))
    if h not in HOUSE_NAMES or delta not in (-10,-5,5,10): return jsonify(ok=False,error='Invalid manual score'),400
    with lock:
        state['scores'][h]+=delta; state['last_event']+=1
        ensure_results();
        try:
            wb=load_workbook(RESULT_FILE); ws=wb['House Scores']
            for row in ws.iter_rows(min_row=2):
                if row[0].value==h: row[1].value=state['scores'][h]
            wb.save(RESULT_FILE)
        except Exception: pass
    return jsonify(ok=True,state=public_state())

@app.post('/api/reset')
def api_reset():
    with lock: reset_state()
    return jsonify(ok=True,state=public_state())

@app.post('/api/reload-excel')
def api_reload():
    errs=read_questions(); return jsonify(ok=not errs,errors=errs)

if __name__=='__main__':
    DATA.mkdir(exist_ok=True); ensure_results(); read_questions()
    app.run(host='0.0.0.0',port=5000,debug=False)
