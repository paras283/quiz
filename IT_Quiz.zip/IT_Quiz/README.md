# Inter-House IT Quiz

Production-oriented Flask application based on the supplied specification. It runs over a school LAN and uses `data/quiz.xlsx` as the primary quiz-content source.

## 1. Install Python
Install Python 3.10+ and ensure `python` is on PATH.

## 2. Install dependencies
```bash
cd IT_Quiz
python -m venv .venv
.venv\\Scripts\\activate
pip install -r requirements.txt
```
On Linux/macOS: `source .venv/bin/activate`.

## 3. Excel format
`data/quiz.xlsx` must contain `Questions` and `RapidFire` sheets. Required columns are documented by the workbook headers. The application validates counts, houses, correct answers, marks, and timers at startup/reload.

## 4. Start server
```bash
python app.py
```
The server listens on `0.0.0.0:5000`.

## 5. Find LAN IP (Windows)
```bat
ipconfig
```
Use the IPv4 address of the host computer, for example `192.168.1.100`.

## 6. Open Presenter
On the projector/presenter computer:
`http://HOST-LAN-IP:5000/`

## 7. Open Control Panel
On the quiz-master computer:
`http://HOST-LAN-IP:5000/control`

## 8. Question preparation
Edit `data/quiz.xlsx` before starting or use **RELOAD QUESTIONS** in the Control Panel. Do not hard-code quiz questions in Python.

## 9. Scoring
Correct and wrong marks come directly from Excel. Round 1 can use zero negative marks; other rounds can use configured negative values. The server is authoritative for scores.

## 10. Passing rounds
Round 3 and Round 4 enter `SELECT HOUSE`. The quiz master selects the answering house, then starts the timer. A wrong answer applies the negative value to that selected house.

## 11. Rapid Fire
After Round 4, the application enters Rapid Fire: 10 questions for each house in the configured house order.

## 12. Reset
**RESET QUIZ** clears server-side quiz state and scores without deleting `quiz.xlsx`.

## 13. Results
Scoring events are written to `data/results.xlsx`, including timestamp, round, question, house, result and marks. House Scores and Final Results sheets are maintained.

## 14. LAN firewall
If other computers cannot connect, allow Python/port 5000 through Windows Defender Firewall on the host computer.

## Notes
- Polling updates state without full-page reloads.
- Correct answers are not sent to the presenter page.
- Missing sound files do not stop the quiz.
- The supplied sample workbook is only a starter template; replace its questions with the school's actual question bank.
